/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clasesgenericas2;

/**
 *
 * @author profl3302
 */
public class Dulce {
    private String marca;

    public Dulce(String marca) {
        this.marca = marca;
    }
    
    
}
