/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pregunta3;

/**
 *
 * @author o23413
 */
public class Nodo {

    public int elem;
    Nodo sig;

    public Nodo(int elem) {
        this.elem = elem;
    }
}
