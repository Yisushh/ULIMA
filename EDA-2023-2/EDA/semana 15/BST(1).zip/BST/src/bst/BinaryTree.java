/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bst;

/**
 *
 * @author ProfO2202
 */
import java.util.Queue;
import java.util.LinkedList;
public class BinaryTree {
    NodoT raiz;
    public void insertarElem(int n){
        raiz=insertarElemRec(raiz,n);
    }
    public NodoT insertarElemRec(NodoT raiz,int n){
        if (raiz==null){
            raiz=new NodoT(n);
        }
        else{
            if (n<raiz.elem){
                raiz.izq=insertarElemRec(raiz.izq,n);
            }
            else{
                raiz.der=insertarElemRec(raiz.der,n);
            }
        }
        return raiz;
    }
    public void inorder(NodoT raiz){
        if (raiz!=null){
            inorder(raiz.izq);
            System.out.print(raiz.elem+" ");
            inorder(raiz.der);
        }
    }
    public void borrar(int n){
        raiz=borrarNodo(raiz,n);
    }
    public NodoT borrarNodo(NodoT curr,int n){
        //curr apunta la raíz del árbol
        if (curr==null){
            System.out.println("no encontrado");
            return null;
        }
        if (n<curr.elem){
            curr.izq=borrarNodo(curr.izq,n);
        }
        else if (n>curr.elem){
                curr.der=borrarNodo(curr.der,n);
            }
        else{
            //caso un sólo hijo a la derecha
            if (curr.izq==null) return curr.der;
            //caso un sólo hijo a la izquierda
            else if (curr.der==null) return curr.izq;
            //caso dos hijos
            curr.elem=menorValor(curr.der);
            curr.der=borrarNodo(curr.der,curr.elem);
        }
        return curr;
    }
    int menorValor(NodoT curr){
        int menor=curr.elem;
        while (curr.izq!=null){
            menor=curr.elem;
            curr=curr.izq;
        }
        return menor;
    }
    int getAltura(NodoT raiz){
        if (raiz==null) return -1;
        else{
            return 1+Math.max(getAltura(raiz.izq),getAltura(raiz.der));
        }
    }
    int getAlturaIter(NodoT raiz){
        if (raiz==null) return 0;
        Queue<NodoT> q=new LinkedList();
        q.add(raiz);
        int altura=-1;
        while(1==1){
            int nodoC=q.size();
            if (nodoC==0) return altura;
            altura++;
            while(nodoC>0){
                NodoT nodo=q.peek();
                q.remove();
                if (nodo.izq!=null) q.add(nodo.izq);
                if (nodo.der!=null) q.add(nodo.der);
                nodoC--;
            }
        }
    }
    public void borrarMenor(){
        if (raiz==null){
            System.out.println("arbol vacio");
        }
        raiz=borrarMenorRec(raiz);
    }
    public NodoT borrarMenorRec(NodoT nodo){
        if (nodo.izq==null){
            return nodo.der;
        }
        nodo.izq=borrarMenorRec(nodo.izq);
        return nodo;
    }
}
